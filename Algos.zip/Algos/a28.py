import time
starttime=time.time()
i=1
p=0
while(i<=50):
    if i%2==0:
        p=p+1
        i=i+1
    else:
        i=i+1

print('Number of even numbers',p)
endtime=time.time()
tt=(endtime-starttime)
print('Total time for execution:',tt)
