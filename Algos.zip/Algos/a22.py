import time
starttime=time.time()
TF=input('ENTER TEMPERATURE IN FARENHIET:')
tf=float(TF)
def tc(f):
    t=(tf-32)*(5/9)
    print("RESPECTIVE TEMPERATURE IN CELCIUS IS:",float(t))
tc(tf)
Tc=input('ENTER TEMPERATURE IN CELCIUS :')
c=float(Tc)
def T(c):
    t1=c*(9/5)+32
    print("RESPECTIVE TEMPERATURE IN FARENHIE IS:",float(t1))
T(c)
endtime=time.time()
tt=(endtime-starttime)
print('TOTAL TIME OF EXECUTION:',tt)
